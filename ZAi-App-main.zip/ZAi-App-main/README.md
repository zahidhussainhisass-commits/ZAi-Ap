# ZAi-App
Zahid Assistant Intelligent – Personal + School AI Assistant
